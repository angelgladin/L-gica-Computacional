╔═════════════════════════════════╗ 
║ Lógica Computacional 2017-2     ║ 
║ Práctica 5: Monerías en Prolog  ║ 
╚═════════════════════════════════╝

╔════════════════╗ 
║ Integrantes    ║ 
╚════════════════╝
● María Ximena Lezama Hernández
  313040131
● Ángel Iván Gladín García
  313040131

╔══════════════════════════════════╗ 
║ Breve Descripción de la práctica ║ 
╚══════════════════════════════════╝
La práctica consiste de 5 Programas realizados en Prolog:
   ● Automatas.pl
     ——Programa el cuál dado un autómata decide si dada una
     lista de caracteres son aceptados por este.
   ● Corte.pl
     ——Programa el cual hace uso de los operadores de corte
     para mejorar el computo.
   ● Diff.pl
     --Programa que hace un flatten de listas diferenciables.
   ● cartoons.hs
     --Programa que hace inferencia para resolver un problema
     dadas una hipótesis, el cual debe debe responder unas
     preguntas.
     ¿Quién es el dueño del perro?
     -batman
     ¿Quién bebe agua?
     -mickey_mouse
   ● mired.pl
     --Programa que simula una Red semántica.

╔═══════════════╗ 
║ Para ejecutar ║ 
╚═══════════════╝
Para ejecutar, hay que situarse en la carpeta src donde se encuentran 
los archivos.pl

AngelGladin
    └── Pract5
      ├── readme.txt
	    └── src
          └── archivos.pl


Y luego escribir en terminar “swipl” y luego “['Elnombredelarchivo.pl']”
╔══════════════╗ 
║ Conclusiones ║ 
╚══════════════╝
Estuvo medio difícil.

╔═══════════════╗ 
║ Bibliografía  ║ 
╚═══════════════╝
Jose E. Labra G.. (Octubre - 1998). Programación Práctica en Prolog : Área de Lenguajes y Sistemas Informáticos Departamento de Informática.



\`*-.                    
)  _`-.                 
.  : `. .                
: _   '  \               
; *` _.   `*-._          
`-.-'          `-.       
;       `       `.     
:.       .        \    
. \  .   :   .-'   .   
'  `+.;  ;  '      :   
:  '  |    ;       ;-. 
; '   : :`-:     _.`* ;
*' /  .*' ; .*`- +'  `*' 
*-*   `*-*  `*-*'   

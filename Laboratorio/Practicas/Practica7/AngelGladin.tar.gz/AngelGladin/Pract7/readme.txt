╔════════════════════════════════════════════════════╗ 
║ Lógica Computacional 2017-2                        ║ 
║ Práctica 7: Deducción natural y lógica ecuacional. ║
╚════════════════════════════════════════════════════╝

╔════════════════╗ 
║ Integrantes    ║ 
╚════════════════╝
● Ángel Iván Gladín García
  313040131
● María Ximena Lezama Hernández
  313040131

╔══════════════════════════════════╗ 
║ Breve Descripción de la práctica ║ 
╚══════════════════════════════════╝
La práctica consistió de un buen de demostraciones
bien largos.
   ● Ultima.v
     ——Está muy larga la descripción, mejor ver todo en el
     PDF de la tarea.

╔═══════════════╗ 
║ Para ejecutar ║ 
╚═══════════════╝
Para ejecutar (en mi caso) se abrirá el archivo de Coq con Emacs, que
está situado en.

AngelGladin
    └── Pract7
    	├── readme.txt
	└── src
            └── archivos.v

Y luego escribir para interactuar tienes que saber usar emacs con
Proof General.

╔══════════════╗ 
║ Conclusiones ║ 
╚══════════════╝
La verdad me encantó la práctica aunque me costo algo de trabajo
agarrarle la onda al principio y también en muchas cosas que me
atoré y decidí pedir ayuda.
Sinceramente creo que estuvo bastante larga y como se entrego
en temporada de fin de semestre, prácticamente me mató eso. :(
Me gustó un montón la práctica, creo que solo pocas veces me
he emocionado tanto haciendo una tarea :v
Hubiera sido excelente si hubiera sido más corta (más que
nada por las fechas, que es fin de semestre).

╔═══════════════╗ 
║ Bibliografía  ║ 
╚═══════════════╝
Lo que se enseñó en la ayudantía.
Todas las veces que le pregunté al ayudante por correo.
Ayuda de mis amigo.
Lo documentación oficial.


\`*-.                    
)  _`-.                 
.  : `. .                
: _   '  \               
; *` _.   `*-._          
`-.-'          `-.       
;       `       `.     
:.       .        \    
. \  .   :   .-'   .   
'  `+.;  ;  '      :   
:  '  |    ;       ;-. 
; '   : :`-:     _.`* ;
*' /  .*' ; .*`- +'  `*' 
*-*   `*-*  `*-*'



      .".".".
    (`       `)               _.-=-.
     '._.--.-;             .-`  -'  '.
    .-'`.o )  \           /  .-_.--'  `\
   `;---) \    ;         /  / ;' _-_.-' `
     `;"`  ;    \        ; .  .'   _-' \
      (    )    |        |  / .-.-'    -`
       '-.-'     \       | .' ` '.-'-\`
        /_./\_.|\_\      ;  ' .'-'.-.
        /         '-._    \` /  _;-,
       |         .-=-.;-._ \  -'-,
       \        /      `";`-`,-"`)
        \       \     '-- `\.\
         '.      '._ '-- '--'/
           `-._     `'----'`;
               `"""--.____,/
                      \\  \
                      // /`
                  ___// /__
                (`(`(---"-`)



                  ,.
                 (\(\)
 ,_              ;  o >
  {`-.          /  (_)
  `={\`-._____/`   |
   `-{ /    -=`\   |
    `={  -= = _/   /
       `\  .-'   /`
        {`-,__.'===,_
        //`        `\\
       //
      `\=


                           .       .
                          / `.   .' " 
                  .---.  <    > <    >  .---.
                  |    \  \ - ~ ~ - /  /    |
      _____          ..-~             ~-..-~
     |     |   \~~~\.'                    `./~~~/
    ---------   \__/                        \__/
   .'  O    \     /               /       \  " 
  (_____,    `._.'               |         }  \/~~~/
   `----.          /       }     |        /    \__/
         `-.      |       /      |       /      `. ,~~|
             ~-.__|      /_ - ~ ^|      /- _      `..-'   
                  |     /        |     /     ~-.     `-. _  _  _
                  |_____|        |_____|         ~ - . _ _ _ _ _>


╔════════════════════════════════════════════════╗ 
║El pollito PIO, El pollito PIO, El pollito PIO. ║
║Oh rayos es un gallo. :v                        ║
╚════════════════════════════════════════════════╝

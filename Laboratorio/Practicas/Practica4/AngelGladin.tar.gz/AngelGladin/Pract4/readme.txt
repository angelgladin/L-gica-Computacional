      María Ximena Lezama Hernández
		313040131
      Ángel Iván Gladín García
		313040131

╔══════════════════════════════════╗ 
║ Breve Descripción de la práctica ║ 
╚══════════════════════════════════╝

La práctica consiste de 3 Programas realizados en Haskell:

	● LPOSust.hs
		——Programa el cuál es la implementación de la sustitución.

	● LPO.hs
		——Programa el cuál implementa la sintaxis de la lógica de 
		predicados o de primer orden.

	● EA.hs
		--Programa que define una semántica para el lenguaje de
        expresiones aritméticas.
    ● EA.hs
        --Programa en el cuál se implementan funciones para
        el algoritmo de Martelli-Montanari.

╔═══════════════╗ 
║ Para ejecutar ║ 
╚═══════════════╝

Para ejecutar, hay que situarse en la carpeta src donde se encuentran 
los archivos.hs
	AngelGladin
        └── Pract4
                ├── readme.txt
                └── src
                    └── archivos.hs


Y luego escribir en terminar “ghci” y luego “:l Elnombredelarchivo.hs”

╔══════════════╗ 
║ Conclusiones ║ 
╚══════════════╝
Estuvo medio difícil.

╔═══════════════╗ 
║ Bibliografía  ║ 
╚═══════════════╝

Miran Lipovača. (2011). Learn You a Haskell for Great Good! : No Starch Press.
 
 

 \`*-.                    
  )  _`-.                 
 .  : `. .                
 : _   '  \               
 ; *` _.   `*-._          
 `-.-'          `-.       
   ;       `       `.     
   :.       .        \    
   . \  .   :   .-'   .   
   '  `+.;  ;  '      :   
   :  '  |    ;       ;-. 
   ; '   : :`-:     _.`* ;
 *' /  .*' ; .*`- +'  `*' 
 *-*   `*-*  `*-*'   